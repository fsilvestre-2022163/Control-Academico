import mongoose from "mongoose";

const studentSchema = mongoose.Schema({
    name:{
        type: String,
        require: true
    },

    age:{
        type: String,
        maxLength: 2,
        minLength: 1,
        require: true
    },

    license:{ //Carnét
        type: String,
        maxLength: 7,
        require: true
    },

    grade:{
        type: String,
        require: true
    },
    
    gender:{
        type: String,
        require: true
    },

    phone:{
        type: String,
        maxLength:8,
        require: true
    },

    courses:{
        type: String,
        require: true
    },

    password:{
        type: String,
        require: true
    },
    role: {
        type: String,
        uppercase: true,
        enum: ['TEACHER', 'STUDENT'], //Solo los datos que estén en el arreglo son válido
        required: true
    }
})

export default mongoose.model('student', studentSchema)