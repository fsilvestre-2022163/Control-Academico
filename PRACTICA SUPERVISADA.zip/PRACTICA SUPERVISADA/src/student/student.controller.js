'use strict'

import Student from './student.model.js'
import { checkPassword, checkUpdate } from '../utils/validator.js'
import { generateJwt } from '../utils/jwt.js'



export const login = async (req, res) => {
    try {
        let { license, password } = req.body
        let student = await Student.findOne({ license })
        if (student && await checkPassword(password, student.password)) {
            let loggedStudent = {
                uid: student._id,
                license: student.license,
                name: student.name,
                role: student.role
            }
        }
        let token = await generateJwt(loggedStudent)
        return res.send(
            {
                message: `Welcome ${student.name}`,
                loggedStudent,
                token
            }
        )
        return res.status(404).send({ message: 'Invalid credentials' })
    } catch (err) {
        console.error(err)
        return res.status(500).send({ message: 'Failed to login' })
    }
}

export const registerStu = async (req, res) => {
    try {
        let data = req.body
        data.role = 'STUDENT'
        let student = new Student(data)
        await student.save()
        return res.send({ message: 'Registered succesfully' })
    } catch (err) {
        console.error(err)
        return res.status(500).send({ message: 'Error registering student' })
    }
}

export const updateStu = async (req, res) => {
    try {
        let { id } = req.params
        let data = req.body
        let update = checkUpdate(data, id)
        if (!update) return res.status(400).send({ message: 'Have sumbmitted some data that cannot be updated or missing data' })
        let updatedStudent = await Student.findOneAndUpdate(
            {_id: id},
            data,
            {new: true}
        )
        if(!updatedStudent) return res.status(401).send({message: 'Student not found and not updated'})
        return res.send({message: 'Updated student', updatedStudent})

    } catch (err) {
        console.error(err)
        return res.status(500).send({ message: 'Error updating student' })
    }
}

export const deleteStu = async(req, res)=>{
    try {
        let {id} = req.params
        let deletedStudent = await Student.findOneAndDelete({_id: id})
        if(!deletedStudent) return res.status(404).send({message: 'Student not found and not deleted'})
        return res.send({message: `Student with name ${deletedStudent.name} deleted successfully`})
    } catch (err) {
        console.error(err)
        return res.status(500).send({message: 'Error deleting student'})
    }
}