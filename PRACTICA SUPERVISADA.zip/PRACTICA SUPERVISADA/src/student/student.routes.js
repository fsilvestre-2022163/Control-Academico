'use strict'

import  {Router}  from 'express'
import { deleteStu, login, registerStu, updateStu } from './student.controller.js'

const api= Router()

api.post('/registerStudent', registerStu)
api.post('/loginStudent', login)
api.put('/updateStudent/:id', updateStu)
api.delete('/deleteStudent/:id', deleteStu)

export default api