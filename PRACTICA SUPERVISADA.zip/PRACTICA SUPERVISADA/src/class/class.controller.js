'use strict'

import Class from './class.model.js'

export  const registerCl = async (req, res)=>{
    try {
        let data = req.body
        let registerC = new Class(data)
        await registerC.save()
        return res.send({message: 'Class succesfully'})
    } catch (err) {
        console.error(err)
        return res.status(500).send({message: 'Error registering Class', err})
    }
}

export const updateCl = async (req, res)=>{
    try {
        let {id} = req.params
        let data = req.body
        let update = checkUpdatecl(data, id)
        if(!update) return res.status(400).send({message:'Have sumbmitted some data that cannot be updated or missing data'})
        let updateClass = await Class.findOneAndUpdate(
            {_id: id}, 
            data, 
            {new: true} 
        )
        if(!updateClass) return res.status(401).send({message: 'Class not found and not updated'})
        return res.send({message: 'Updated class', updateClass})
    } catch (err) {
        console.error(err)
        return res.status(500).send({message: 'Error updating Class'})
    }
}

export const deleteCl = async (req, res)=>{
    try {
        let {id} = req.params
        let deleteClass = await Class.findOneAndDelete({_id:id})
        if(!deleteClass) return res.status(404).send({message: 'Class not found and not deleted'})
        return res.send({message: `Class with name ${deleteClass.name} deleted successfully`})
    } catch (err) {
        console.error(err)
        return res.status(500).send({message: 'Error deleting Class'})
    }
}