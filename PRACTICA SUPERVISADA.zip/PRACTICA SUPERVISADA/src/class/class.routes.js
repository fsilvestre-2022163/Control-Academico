'use strict'

import express from 'express'
import { deleteCl, registerCl, updateCl } from './class.controller.js'

const api = express.Router()

api.post('/registerClass', registerCl)
api.put('/updateClass/:id', updateCl)
api.delete('/deleteClass/:id', deleteCl)

export default api