'use strict'

import { generateJwt } from '../utils/jwt.js'
import { checkPassword, checkUpdate, checkUpdateTe } from '../utils/validator.js'
import Teacher from './teacher.model.js'

export const loginTe = async(req, res) =>{
    try {
        let {name, password}= req.body
        let teacher = await Teacher.findOne({name})
        if(teacher && await checkPassword(password, teacher.password)){
            let loggedTeacher = {
                uid: teacher._id,
                name: teacher.name,
                subject: teacher.subject,
                role: teacher.role
            }
            let token = await generateJwt(loggedTeacher)
            return res.send(
                {
                    messaje: `Welcome ${Teacher.name}`,
                    loggedTeacher,
                    token
                }
            )
        }
        return res.status(404).send({message: 'Invalid credentials'})
    } catch (err) {
        console.error(err)
        return res.status(500).send({message: 'Failed to login'})
    }
}


export  const registerTe = async (req, res)=>{
    try {
        let data = req.body
        data.role = 'TEACHER'
        let teacher = new Teacher(data)
        await teacher.save()
        return res.send({message: 'Registered succesfully'})
    } catch (err) {
        console.error(err)
        return res.status(500).send({message: 'Error registering teacher', err})
    }
}

export const updateTe = async (req, res)=>{
    try {
        let {id} = req.params
        let data = req.body
        let update = checkUpdateTe(data, id)
        if(!update) return res.status(400).send({message:'Have sumbmitted some data that cannot be updated or missing data'})
        let updateTeacher = await Teacher.findOneAndUpdate(
            {_id: id}, 
            data, 
            {new: true} 
        )
        if(!updateTeacher) return res.status(401).send({message: 'Teacher not found and not updated'})
        return res.send({message: 'Updated teacher', updateTeacher})
    } catch (err) {
        console.error(err)
        return res.status(500).send({message: 'Error updating teacher'})
    }
}

export const deleteTe = async (req, res)=>{
    try {
        let {id} = req.params
        let deleteTeacher = await Teacher.findOneAndDelete({_id:id})
        if(!deleteTeacher) return res.status(404).send({message: 'Teacher not found and not deleted'})
        return res.send({message: `Teacher with name ${deleteTeacher.name} deleted successfully`})
    } catch (err) {
        console.error(err)
        return res.status(500).send({message: 'Error deleting teacher'})
    }
}


