import mongoose from "mongoose";

const teacherSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },

    age: {
        type: String,
        maxLength: 2,
        required: true
    },

    phone: {
        type: String,
        maxLength: 8,
        required: true
    },
    password:{
        type: String,
        required: true
    },

    email: {
        type: String,
        required: true
    },

    subject: {
        type: String,
        required: true
    },

    role: {
        type: String,
        enum: ['TEACHER'],
        required: true
    }
})
export default mongoose.model('teacher', teacherSchema)