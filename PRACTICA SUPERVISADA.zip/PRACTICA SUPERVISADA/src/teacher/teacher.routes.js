'use strict'

import express from 'express'
import { deleteTe, loginTe, registerTe, updateTe } from './teacher.controller.js'

const api = express.Router()

api.post('/loginTeacher', loginTe)
api.post('/registerTeacher', registerTe)
api.put('/updateTeacher/:id', updateTe)
api.delete('/deleteTeacher/:id', deleteTe)

export default api